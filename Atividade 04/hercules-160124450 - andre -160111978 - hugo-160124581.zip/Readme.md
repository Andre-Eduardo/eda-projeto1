#				Integrantes

* Hugo Aragão de Oliveira - 16/0124581
* Hércules Ismael de Abreu Santos - 16/0124450
* André Eduardo Souza de Oliveira - 16/0111978







#				Instruções para execução do programa


	*  O programa deve ser compilado de preferência em um terminal linux
	*  Para compilar digite -> make
	*  Para executar digite -> ./main
	*  Para excluir arquivos de compilação -> make clean
